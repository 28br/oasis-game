const express = require("express");
const http = require("http");
const { WebSocketServer } = require("ws");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
app.use(express.static(path.join(__dirname, "public")));

const players = new Map();
let nextId = 1;

function broadcast(data, except=null) {
  const msg = JSON.stringify(data);
  for (const [id, ws] of wss.clients.entries()) {
    if (ws.readyState === 1 && ws !== except) ws.send(msg);
  }
}

wss.on("connection", ws => {
  const id = String(nextId++);
  const player = {
    id, name: "Player", x: 0, y: 1.8, z: 12,
    yaw: 0, world: "OASIS City", skin:"#d59b72", suit:"#26caff", hair:"#171923"
  };
  players.set(id, player);

  ws.send(JSON.stringify({type:"welcome", id, players:[...players.values()]}));
  broadcast({type:"join", player}, ws);

  ws.on("message", raw => {
    try {
      const msg = JSON.parse(raw);
      if (msg.type === "state") {
        Object.assign(player, {
          name: String(msg.name || player.name).slice(0,16),
          x: Number(msg.x)||0, y: Number(msg.y)||1.8, z: Number(msg.z)||0,
          yaw: Number(msg.yaw)||0, world: String(msg.world||"OASIS City").slice(0,30),
          skin: msg.skin || player.skin, suit: msg.suit || player.suit, hair: msg.hair || player.hair
        });
        broadcast({type:"update", player}, ws);
      }
      if (msg.type === "chat") {
        const text = String(msg.text || "").trim().slice(0,160);
        if (text) broadcast({type:"chat", id, name:player.name, text});
      }
      if (msg.type === "world") {
        player.world = String(msg.world||"OASIS City").slice(0,30);
        broadcast({type:"update", player});
      }
    } catch {}
  });

  ws.on("close", () => {
    players.delete(id);
    broadcast({type:"leave", id});
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Mini-OASIS multiplayer server running on http://localhost:${PORT}`));
