# Mini-OASIS Multiplayer

This is a small client/server multiplayer prototype.

## Run it
1. Install Node.js (LTS).
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000 in a browser.
6. Open the same address in another browser/device on the same network to test multiple players.

The server synchronizes player position, appearance, world, joins/leaves, and chat.

## Important
For internet-wide multiplayer, deploy the Node server to a hosting service and use HTTPS/WSS. This prototype does not include authentication, anti-cheat, matchmaking, persistent accounts, or production security.
